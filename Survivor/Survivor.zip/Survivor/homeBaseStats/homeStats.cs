﻿namespace homeBaseStats
{
    internal class homeStats
    {
    }
}