﻿using UnityEngine;
using System.Collections;

public class Stats{

    public string randomName;
    public int cooking;
    public int combat;
    public int medicine;
    public int technology;
}
